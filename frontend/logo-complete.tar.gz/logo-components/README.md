# Комплект логотипа для использования в других проектах

## 📁 Структура файлов

```
logo-components/
├── README.md                    # Этот файл
├── logo-svg.html                # HTML пример с SVG логотипом
├── logo-macro.blade.php         # Blade макрос для Laravel
├── Logo.jsx                     # React компонент
├── logo-styles.css              # CSS стили для логотипа
└── logo-usage-examples.md       # Примеры использования в разных фреймворках
```

## 🎨 Что включено

### 1. SVG Иконка
- Векторная иконка с градиентами и эффектом глубины
- Автоматически адаптируется к теме через `currentColor`
- Работает в светлой и темной теме

### 2. Текст логотипа
- Настраиваемое название приложения
- Для Laravel: `config('variables.templateName')` = "REXTEN"
- Для React: `APP_NAME` = "Ecme"

### 3. Стили
- Полный набор CSS стилей
- Поддержка темной темы
- Адаптивность для мобильных устройств
- Анимации и переходы

## 🚀 Быстрый старт

### Для Laravel/Blade проектов:

1. Скопируйте `logo-macro.blade.php` в `resources/views/_partials/macros.blade.php`
2. Используйте в шаблонах:
```blade
<a href="{{ url('/') }}" class="app-brand-link gap-2">
  <span class="app-brand-logo demo">@include('_partials.macros')</span>
  <span class="app-brand-text demo menu-text fw-bold text-heading">{{ config('variables.templateName') }}</span>
</a>
```

### Для React/Next.js проектов:

1. Скопируйте `Logo.jsx` в ваш проект
2. Создайте PNG изображения логотипа (см. ниже)
3. Используйте компонент:
```jsx
import Logo from '@/components/template/Logo'
import useTheme from '@/utils/hooks/useTheme'

const HeaderLogo = () => {
    const mode = useTheme((state) => state.mode)
    return <Logo mode={mode} type="full" />
}
```

### Для обычного HTML:

1. Откройте `logo-svg.html` как пример
2. Скопируйте SVG код и CSS стили
3. Настройте название приложения

## 📸 Необходимые изображения (для React версии)

Если используете React компонент, вам понадобятся PNG файлы:

- `/public/img/logo/logo-light-full.png` - Полный логотип (светлая тема)
- `/public/img/logo/logo-dark-full.png` - Полный логотип (темная тема)
- `/public/img/logo/logo-light-streamline.png` - Только иконка (светлая тема)
- `/public/img/logo/logo-dark-streamline.png` - Только иконка (темная тема)

**Совет:** Создайте PNG на основе SVG иконки, добавив текст логотипа.

## 🎨 Настройка цветов

Цвета настраиваются через CSS переменные:

```css
:root {
  --primary-color: #696cff;           /* Цвет иконки (светлая тема) */
  --text-heading-color: #566a7f;      /* Цвет текста (светлая тема) */
}

[data-bs-theme="dark"] {
  --primary-color-dark: #696cff;      /* Цвет иконки (темная тема) */
  --text-heading-color-dark: #a1acb8; /* Цвет текста (темная тема) */
}
```

## 📝 Настройка названия

### Laravel:
Отредактируйте `config/variables.php`:
```php
"templateName" => "ВАШЕ_НАЗВАНИЕ",
```

### React:
Отредактируйте константу в `Logo.jsx`:
```jsx
const APP_NAME = 'ВАШЕ_НАЗВАНИЕ'
```

## 🔧 Дополнительные настройки

### Размеры логотипа

В Blade:
```blade
@include('_partials.macros', ['width' => '40'])
```

В React:
```jsx
<Logo logoWidth={150} logoHeight={50} />
```

### Типы логотипа (React)

- `type="full"` - Иконка + текст
- `type="streamline"` - Только иконка

## 📚 Дополнительная документация

См. файл `LOGO_COMPLETE.md` в корне проекта для полной документации.

## ⚠️ Важные замечания

1. SVG использует `currentColor` - цвет берется из CSS класса `text-primary`
2. Для React версии нужны PNG изображения (создайте на основе SVG)
3. Убедитесь, что цветовая схема настроена для обеих тем
4. CSS переменные должны быть определены в вашем проекте

## 🎯 Поддерживаемые фреймворки

- ✅ Laravel/Blade
- ✅ React/Next.js
- ✅ Vue.js
- ✅ Angular
- ✅ Обычный HTML/CSS/JS

## 📞 Поддержка

Если у вас возникли вопросы, обратитесь к полной документации в `LOGO_COMPLETE.md`.

