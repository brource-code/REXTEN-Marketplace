@php
  $width = $width ?? '30';
@endphp

<span class="text-primary">
  <svg width="{{ $width }}" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
      <!-- Градиенты для слоев -->
      <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:currentColor;stop-opacity:1" />
        <stop offset="100%" style="stop-color:currentColor;stop-opacity:0.6" />
      </linearGradient>
      <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:currentColor;stop-opacity:0.8" />
        <stop offset="100%" style="stop-color:currentColor;stop-opacity:0.4" />
      </linearGradient>
      <linearGradient id="gradient3" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:currentColor;stop-opacity:0.6" />
        <stop offset="100%" style="stop-color:currentColor;stop-opacity:0.2" />
      </linearGradient>

      <!-- Основной слой -->
      <path d="M4 8L15 2L26 8L15 14L4 8Z" id="layer-1"></path>
      <!-- Второй слой -->
      <path d="M4 14L15 8L26 14L15 20L4 14Z" id="layer-2"></path>
      <!-- Третий слой -->
      <path d="M4 20L15 14L26 20L15 26L4 20Z" id="layer-3"></path>
    </defs>
    <g id="g-app-brand" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
      <g id="Brand-Logo" transform="translate(0, 0)">
        <g id="Icon">
          <!-- Основной слой с градиентом -->
          <g id="Layer-1">
            <use fill="url(#gradient1)" xlink:href="#layer-1"></use>
            <use fill-opacity="0.3" fill="#FFFFFF" xlink:href="#layer-1"></use>
          </g>
          <!-- Второй слой с эффектом глубины -->
          <g id="Layer-2" transform="translate(1, 2)">
            <use fill="url(#gradient2)" xlink:href="#layer-2"></use>
            <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#layer-2"></use>
          </g>
          <!-- Третий слой с эффектом глубины -->
          <g id="Layer-3" transform="translate(2, 4)">
            <use fill="url(#gradient3)" xlink:href="#layer-3"></use>
            <use fill-opacity="0.1" fill="#FFFFFF" xlink:href="#layer-3"></use>
          </g>
        </g>
      </g>
    </g>
  </svg>
</span>

